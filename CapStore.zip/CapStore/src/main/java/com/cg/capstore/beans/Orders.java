package com.cg.capstore.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Orders {

	@Id
	private int orderId;
	private Product product;// get product name and price
	private int userId;
	private double totalAmount;
	private String deliveryStatus;// placed, shipped, out for delivery 
	private String statusOfTransaction; //Success or fail
	private String modeOfPurchase;// can be COD, Online Purchase
	private Merchant merchant;// get merchant name ,one to many
	private Date elligibleReturnDate;
	private Date orderPlacedOn;
	private boolean refundRequest;
	private Customer customer;//one to one
}
