package com.cg.capstore.beans;

public class Inventory {

	private Product product;//one to many
	private Category category;//one to many
	private Merchant merchant;//one to one
}
