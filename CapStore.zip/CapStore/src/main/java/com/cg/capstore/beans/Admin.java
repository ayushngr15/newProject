package com.cg.capstore.beans;

public class Admin {

	private Merchant merchant;// one to many
	private Coupon coupon;// one to many
	private Discount discount;// one to many
}
