package com.cg.capstore.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Coupon {

	@Id
	private int couponId;
	private Date couponStartDate;
	private Date couponEndDate;
	private int productId;//one to one
	private String couponName;//??
	private double couponDiscountValue;
}
