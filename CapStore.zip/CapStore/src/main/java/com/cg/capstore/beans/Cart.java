package com.cg.capstore.beans;

public class Cart {

	private Customer customer;//one to one
	private Product product;//one to many
	private int quantityRequired;//max 5
	private double totalAmount;
}
