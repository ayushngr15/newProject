package com.cg.capstore.beans;

public class WishList {
	private Customer customer;// one to one
	private Product product;// one to many
}
