package com.cg.capstore.beans;

import java.util.Date;

import javax.persistence.Entity;
@Entity
public class Product {

	
	private int productId;
	private String productName;
	private String productDesc;
	private String productImageURL;
	private String productBannerURL;
	private double productPrice;
	private int productQuantityAvailable;
	private Review review;//one to many
	private Discount discount;//one to one
	private long productViews;
	private long productTimesBought;
	private boolean productStatus;
	private Date deliveryDate;
	private Date productAddedDate;
	private String brand;
	private Date productRemovedDate;
}
