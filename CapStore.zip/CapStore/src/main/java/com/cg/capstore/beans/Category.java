package com.cg.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Category {

	@Id
	private int categoryId;
	private Product product;
	private String categoryName;//Clothes, books, gadgets
	private String type;		// shirts, pants, dresses in clothing
}
