package com.cg.capstore.beans;

public class Address {

	private Customer customer;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String country;
	private int zipcode;
	
}
