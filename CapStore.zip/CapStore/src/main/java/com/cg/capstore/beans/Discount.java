package com.cg.capstore.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Discount {

	@Id
	private int discountId;
	private Date startDateOfDiscount;
	private Date endDateOfDiscount;
	private Product product;//one to one
	
	private double percentDiscount;
	private Merchant merchant;// ??
}
