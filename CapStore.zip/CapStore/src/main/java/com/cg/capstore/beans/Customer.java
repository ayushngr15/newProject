package com.cg.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Customer {

	@Id
	private String phoneNumber;
	private Address address;
	private String email;
	private String password;
	private String cardNumber;
	private String securityQuestion;
	private String securityAnswer;

}
