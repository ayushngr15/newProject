package com.cg.capstore.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Merchant {

	@Id
	private int merchantId;
	private boolean isThirdPartyMerchant;
	private Product product;
	private Discount discount;
	private Coupon coupon;
	private Date addMerchantDate;
}
