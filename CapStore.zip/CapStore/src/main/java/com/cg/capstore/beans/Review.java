package com.cg.capstore.beans;

public class Review {

	private int reviewId;
	private Product product;//one to one
	private String comments;
	private Customer customer;//one to one
	private int productRating;
	private Merchant merchant;//one to one
}
