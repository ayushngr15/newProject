package com.cg.mywalletapp.repo;






import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.mywalletapp.beans.Customer;




public interface CustomerRepo extends JpaRepository<Customer, String>{
	

 
	

	
}
